define({
      "button.fontfamily.tooltip": "Font" ,
      "button.fontfamily.text": "F" ,
}
);
