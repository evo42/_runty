Aloha-Plugin-FontSize
=====================

FontSize plugin for Aloha Editor