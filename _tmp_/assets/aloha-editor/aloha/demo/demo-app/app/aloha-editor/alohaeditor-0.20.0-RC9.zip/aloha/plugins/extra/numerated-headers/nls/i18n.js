define({
	root: { "button.numeratedHeaders.tooltip": "Toggle header numeration." },
	"de":true,
	"en":true
});