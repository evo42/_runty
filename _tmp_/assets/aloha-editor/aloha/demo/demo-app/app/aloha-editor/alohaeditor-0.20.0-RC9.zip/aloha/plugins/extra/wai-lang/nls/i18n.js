define({
	root: {},
	"de":true,
	"en":true
});