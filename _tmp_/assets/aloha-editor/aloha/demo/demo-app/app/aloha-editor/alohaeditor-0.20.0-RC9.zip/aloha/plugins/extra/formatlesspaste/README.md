Paste plugin allows to handle some different contents that are pasted into the editable area.

This plugin is released under the AGPL license.
