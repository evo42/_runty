define({
	root: { 
		"plugin1.test1": "fallback"
	},
	"de":true
});