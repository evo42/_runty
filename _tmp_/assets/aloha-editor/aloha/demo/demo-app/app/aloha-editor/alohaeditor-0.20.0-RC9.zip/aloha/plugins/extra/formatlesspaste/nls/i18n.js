define({
	root: {"button.formatlessPaste.tooltip":"Toggle Formatless Pasting"}
,	"de":true,
	"fr":true,
	"pl":true,
	"ru":true
});
