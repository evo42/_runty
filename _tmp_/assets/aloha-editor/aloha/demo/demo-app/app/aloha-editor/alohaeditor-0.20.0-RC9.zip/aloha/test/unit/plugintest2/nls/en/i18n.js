define({ 
	"plugin2.test1": "english" 
});