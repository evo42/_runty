define({ 
	"plugin1.test1": "english" 
});