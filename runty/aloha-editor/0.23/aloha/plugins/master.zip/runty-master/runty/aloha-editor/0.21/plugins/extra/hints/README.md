Alhoa-Editor Hints Plugin
===================================
This plugin will allow you to display tooltip hints besides editables.

Usage
=====
Just include the plugin like any other Aloha plugin.
At the moment, whatever resides in the "title" attribute of an editable will be appear to the right in a fancy, semi-transparent hint.

Known Issues
============
* No external configuration yet (all defaults live in hints-plugin.js)