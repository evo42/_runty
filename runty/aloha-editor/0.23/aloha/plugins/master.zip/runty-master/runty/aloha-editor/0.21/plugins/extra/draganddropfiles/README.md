Aloha Editor Plugin for handling drop of files from user's desktop
Configurable options
* max file size object
* max dropped files count
Author: 2010 Nicolas Karageuzian