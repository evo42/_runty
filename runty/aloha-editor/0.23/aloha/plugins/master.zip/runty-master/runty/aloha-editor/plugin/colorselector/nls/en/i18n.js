define({
      "button.colorselector.tooltip": "Highlight" ,
      "button.fontcolorselector.tooltip": "Font Color"}
);
