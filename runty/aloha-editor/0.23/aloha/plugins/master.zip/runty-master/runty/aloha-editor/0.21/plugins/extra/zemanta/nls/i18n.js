define({
	root: {
		"floatingmenu.tab.related":"Related",
		"button.zemanta.tooltip":"Zemanta",
		"zemanta.message.shorttext":"To find related articles, images or tags the Zemanta service needs more then 140 characters."
	},
	"de": false
});