define({"button.addimage.tooltip":"Ins\u00e9rer une image",
	    "button.removeimage.tooltip":"Supprimer l'image",
	    "newimage.defaulttext":"Nouvelle image",
	    "floatingmenu.tab.img":"Image"});