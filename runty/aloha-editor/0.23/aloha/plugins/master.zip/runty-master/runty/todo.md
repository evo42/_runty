Runty NoCMS ToDos

* rename icons / validate other icon option (css/font) + create html index viewer
* copy @todo from source to here
* install stanbol for linked data repository
* 